'use strict';

module.exports = function(Floor3) {

};
