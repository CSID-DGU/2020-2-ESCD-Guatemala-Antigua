'use strict';

module.exports = function(Purchaselog) {

};
