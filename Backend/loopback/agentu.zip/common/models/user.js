'use strict';

module.exports = function(User) {

};
