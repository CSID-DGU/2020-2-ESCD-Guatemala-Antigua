'use strict';

module.exports = function(Foodallergy) {

};
