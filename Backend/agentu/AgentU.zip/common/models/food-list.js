'use strict';

module.exports = function(Foodlist) {

};
