'use strict';

module.exports = function(Allergylist) {

};
