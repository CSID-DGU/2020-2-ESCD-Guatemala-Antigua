'use strict';

module.exports = function(Facilitytype) {

};
