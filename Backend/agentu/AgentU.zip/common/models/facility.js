'use strict';

module.exports = function(Facility) {

};
