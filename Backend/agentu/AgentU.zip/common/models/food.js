'use strict';

module.exports = function(Food) {

};
